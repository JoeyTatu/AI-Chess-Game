/**
 * @author Keith Feeney - x15015556@student.ncirl.ie
 * @author National College of Ireland - info@ncirl.ie
 * @filename AIAgent.java
 * @date 15 January 2019
 */

 import java.util.*;

public class AIAgent{
  Random rand;

  public AIAgent(){
    rand = new Random();
  }

/*
  The method randomMove takes as input a stack of potential moves that the AI agent
  can make. The agent uses a rondom number generator to randomly select a move from
  the inputted Stack and returns this to the calling agent.
*/
/********************************************Random Move***************************************************************/
  public Move randomMove(Stack possibilities){

    int moveID = rand.nextInt(possibilities.size());
    System.out.println("Agent randomly selected move : "+moveID);
    for(int i=1;i < (possibilities.size()-(moveID));i++){
      possibilities.pop();
    }
    Move selectedMove = (Move)possibilities.pop();
    return selectedMove;
  }
/********************************************Next Best Move***************************************************************/
  public Move nextBestMove(Stack whitePossibilitiesStack, Stack blackPossibilitiesStack) {
        Stack backupMove = (Stack) whitePossibilitiesStack.clone();
        Stack blackStackM = (Stack) blackPossibilitiesStack.clone();
        Move bestMove = null;
        Move whiteMove;
        Move presentMove;
        Square blackPosition;
        int Value = 0;
        int chosenPieceValue = 0;

        while (!whitePossibilitiesStack.empty()) {
            whiteMove = (Move) whitePossibilitiesStack.pop();
            presentMove = whiteMove;

            //Checking the center of the board for piece
            if ((presentMove.getStart().getYC() < presentMove.getLanding().getYC())
            && (presentMove.getLanding().getXC() == 3) && (presentMove.getLanding().getYC() == 3)
            || (presentMove.getLanding().getXC() == 4) && (presentMove.getLanding().getYC() == 3)
            || (presentMove.getLanding().getXC() == 3) && (presentMove.getLanding().getYC() == 4)
            || (presentMove.getLanding().getXC() == 4) && (presentMove.getLanding().getYC() == 4)) {

              Value = 1;

            //update best move
                if (Value > chosenPieceValue) {
                    chosenPieceValue = Value;
                    bestMove = presentMove;
                }
            }

            //compare white landing positions to black positions.
            while (!blackStackM.isEmpty()) {
                Value = 0;
                blackPosition = (Square) blackStackM.pop();
                if ((presentMove.getLanding().getXC() == blackPosition.getXC()) && (presentMove.getLanding().getYC() == blackPosition.getYC())) {

                    //Assign Value to pieces
                    if (blackPosition.getName().equals("BlackQueen")) {
                        Value = 5;
                    } else if (blackPosition.getName().equals("BlackRook")) {
                        Value = 4;
                    } else if (blackPosition.getName().equals("BlackBishop") || blackPosition.getName().equals("BlackKnight")) {
                        Value = 3;
                    } else if (blackPosition.getName().equals("BlackPawn")) {
                        Value = 2;
                    } else {
                        Value = 6;
                    }
                }
                //updating the best move
                if (Value > chosenPieceValue) {
                    chosenPieceValue = Value;
                    bestMove = presentMove;
                }
            }
            //reloading the black squares
            blackStackM = (Stack) blackPossibilitiesStack.clone();
        }

        // Make the best move
        if (chosenPieceValue > 0) {
            System.out.println("Selected AI Agent - Next best move: " +chosenPieceValue);
            return bestMove;
        }

        return randomMove(backupMove);

    }


/********************************************Two Level Deep***************************************************************/
/*

this is going to be similar to the nextBestMove
it is going to behave like human brain where you think about your own pieces and the opponent
*/
public Move twoLevelsDeep(Stack possibilities){
  Move selectedMove = new Move();
  return selectedMove;
}
}
