/**
 * @author Keith Feeney - x15015556@student.ncirl.ie
 * @author National College of Ireland - info@ncirl.ie
 * @filename Move.java
 * @date 15 January 2019
 */

 class Move{
  Square start;
  Square landing;

  public Move(Square x, Square y){
    start = x;
    landing = y;
  }

  public Move(){
    
  }

  public Square getStart(){
    return start;
  }

  public Square getLanding(){
    return landing;
  }
}
