import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

/*
	@author: Keith Feeney - Student ID: 15015556 - Email: keith.feeney@student.ncirl.ie
	@author: Keith Maycock
	@author: National College of Ireland - ncirl.ie
	@created: NULL //unknown 
	@modified: 12 October 2018
*/
/*
	This class can be used as a starting point for creating your Chess game project. The only piece that 
	has been coded is a white pawn...a lot done, more to do!
*/

public class ChessProject extends JFrame implements MouseListener, MouseMotionListener {
	JLayeredPane layeredPane;
	JPanel chessBoard;
	JPanel panels;
	JLabel chessPiece;
	JLabel pieces;

	int xAdjustment;
	int yAdjustment;
	int startX;
	int startY;
	int initialX;
	int initialY;

	Boolean progression = false;;
	Boolean success = false;;

	// Boolean gameOver = false;
	// Boolean whiteMoves = true;

	public ChessProject() {
		Dimension boardSize = new Dimension(600, 600);

		// Use a Layered Pane for this application
		layeredPane = new JLayeredPane();
		getContentPane().add(layeredPane);
		layeredPane.setPreferredSize(boardSize);
		layeredPane.addMouseListener(this);
		layeredPane.addMouseMotionListener(this);

		// Add a chess board to the Layered Pane
		chessBoard = new JPanel();
		layeredPane.add(chessBoard, JLayeredPane.DEFAULT_LAYER);
		chessBoard.setLayout(new GridLayout(8, 8));
		chessBoard.setPreferredSize(boardSize);
		chessBoard.setBounds(0, 0, boardSize.width, boardSize.height);

		for (int i = 0; i < 64; i++) {
			JPanel square = new JPanel(new BorderLayout());
			chessBoard.add(square);

			int row = (i / 8) % 2;
			if (row == 0)
				square.setBackground(i % 2 == 0 ? Color.white : Color.gray);
			else
				square.setBackground(i % 2 == 0 ? Color.gray : Color.white);
		}

		// Setting up the Initial Chess board.
		for (int i = 8; i < 16; i++) {
			pieces = new JLabel(new ImageIcon("WhitePawn.png"));
			panels = (JPanel) chessBoard.getComponent(i);
			panels.add(pieces);
		}
		pieces = new JLabel(new ImageIcon("WhiteRook.png"));
		panels = (JPanel) chessBoard.getComponent(0);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteKnight.png"));
		panels = (JPanel) chessBoard.getComponent(1);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteKnight.png"));
		panels = (JPanel) chessBoard.getComponent(6);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteBishop.png"));
		panels = (JPanel) chessBoard.getComponent(2);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteBishop.png"));
		panels = (JPanel) chessBoard.getComponent(5);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteKing.png"));
		panels = (JPanel) chessBoard.getComponent(3);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteQueen.png"));
		panels = (JPanel) chessBoard.getComponent(4);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("WhiteRook.png"));
		panels = (JPanel) chessBoard.getComponent(7);
		panels.add(pieces);
		for (int i = 48; i < 56; i++) {
			pieces = new JLabel(new ImageIcon("BlackPawn.png"));
			panels = (JPanel) chessBoard.getComponent(i);
			panels.add(pieces);
		}
		pieces = new JLabel(new ImageIcon("BlackRook.png"));
		panels = (JPanel) chessBoard.getComponent(56);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackKnight.png"));
		panels = (JPanel) chessBoard.getComponent(57);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackKnight.png"));
		panels = (JPanel) chessBoard.getComponent(62);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackBishop.png"));
		panels = (JPanel) chessBoard.getComponent(58);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackBishop.png"));
		panels = (JPanel) chessBoard.getComponent(61);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackKing.png"));
		panels = (JPanel) chessBoard.getComponent(59);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackQueen.png"));
		panels = (JPanel) chessBoard.getComponent(60);
		panels.add(pieces);
		pieces = new JLabel(new ImageIcon("BlackRook.png"));
		panels = (JPanel) chessBoard.getComponent(63);
		panels.add(pieces);
	}

	/*
	 * This method checks if there is a piece present on a particular square.
	 */
	private Boolean piecePresent(int x, int y) {
		Component c = chessBoard.findComponentAt(x, y);
		if (c instanceof JPanel) {
			return false;
		} else {
			return true;
		}
	}

	/*
	 * This is a method to check if a piece is a Black piece.
	 */
////// METHOD USED TO CHECK WHETHER A PIECE IS AN OPONENT OF WHITE
	private Boolean checkWhiteOponent(int newX, int newY) {
		Boolean oponent;
		Component c1 = chessBoard.findComponentAt(newX, newY);
		JLabel awaitingPiece = (JLabel) c1;
		String tmp1 = awaitingPiece.getIcon().toString();
		if (((tmp1.contains("Black")))) {
			if (tmp1.contains("King")) {
				oponent = true;
				// gameEnds("White");
			}
			oponent = true;
		} else {
			oponent = false;
		}
		return oponent;
	}

////// METHOD USED TO CHECK WHETHER A PIECE IS AN OPONENT OF BLACK
	private Boolean checkBlackOponent(int newX, int newY) {
		Boolean oponent;
		Component c1 = chessBoard.findComponentAt(newX, newY);
		JLabel awaitingPiece = (JLabel) c1;
		String tmp1 = awaitingPiece.getIcon().toString();
		if (((tmp1.contains("White")))) {
			if (tmp1.contains("King")) {
				// gameEnds("Black");
			}
			oponent = true;
		} else {
			oponent = false;
		}
		return oponent;
	}

////METHOD USED WITH isKingNearby() TO GET STRING NAME OF PIECE	
	private String getPieceName(int x, int y) {
		Component c = chessBoard.findComponentAt(x, y);
		if ((c instanceof JLabel)) {
			JLabel awaitingPiece = (JLabel) c;
			return awaitingPiece.getIcon().toString(); // gets String name of chess piece at x,y
		} else {
			return "";
		}
	}

////METHOD TO SEE IF THE KING CAN MOVE. IF OTHER KING IS WITHIN 2 SPACES, IT'S NOT ALLOWED.	
	private Boolean isKingNearby(int x, int y) { // is king where the piece is landing

		if (((piecePresent(x, y + 75)) && getPieceName(x, y + 75).contains("King")) ||// at piecePresent x,y+1, get the string in pieceName if contains "King"
				((piecePresent(x, y - 75)) && getPieceName(x, y - 75).contains("King")) ||// at piecePresent x,y-1, get the string in pieceName if contains "King"
				((piecePresent(x + 75, y)) && getPieceName(x + 75, y).contains("King")) || // at piecePresent x+1,y, get the string in pieceName if contains "King"
				((piecePresent(x - 75, y)) && getPieceName(x - 75, y).contains("King")) || // at piecePresent x-1,y, get the string in pieceName if contains "King"
				((piecePresent(x + 75, y + 75)) && getPieceName(x + 75, y + 75).contains("King")) || // at piecePresent x+1,y+1, get the string in pieceName if contains "King"
				((piecePresent(x - 75, y - 75)) && getPieceName(x - 75, y - 75).contains("King")) || // at piecePresent x-1,y-1, get the string in pieceName if contains "King"
				((piecePresent(x + 75, y - 75)) && getPieceName(x + 75, y - 75).contains("King")) || // at piecePresent x+1,y-1, get the string in pieceName if contains "King"
				((piecePresent(x - 75, y + 75)) && getPieceName(x - 75, y + 75).contains("King"))) { // at piecePresent x-1,y+1, get the string in pieceName if contains "King"
			return true;
		} else {
			return false;
		}

	}

/* 	private Boolean negLandingX(int getX){ // tried using methods to fix some pices going outside the chess board, I over complicated it.
		Boolean negative;
		getX = e.getX();
		if(getX < 0){
			negative = true;
		}
		else{
			negative = false;
		}
		return negative;
	}

	private Boolean negLandingY(int getY){
		Boolean negative;
		getY = e.getY();
		if(getY < 0){
			negative = true;
		}
		else{
			negative = false;
		}
		return negative;
	} */


////METHOD TO SEE IF KING IS CAPTURED AND TO WIN THE GAME - ATTEMPT
	//private Boolean isKingCaputered(int startX, int startY ,int x, int y){ 
		//was having issues with the Queen not "winning" so took in the startX and startY to see if String name contained "Queen"

	/* if(getPieceName(x, y).contains("Queen")) {
		progression = false;
		success = false; // my issue was that ,,if (getPieceName(x, y).contains("BlackKing")) {,, said "equals", not "contains"
	} 
	if ((piecePresent(x, y)) && getPieceName(x, y).contains("King")) { // similar to isKingNearby(), but this gets
																			// the x,y of where the piece is landing.

			if (getPieceName(x, y).equals("BlackKing")) { // if it's a black king, white wins
				JOptionPane.showMessageDialog(null, "White wins!");
				System.exit(0);
			} else if (getPieceName(x, y).contains("WhiteKing")) { // if it's a white king, white wins
				JOptionPane.showMessageDialog(null, "Black wins!");
				System.exit(0);
			}
			return true;
		}
		// else if((piecePresent(x, y)) && getPieceName(x, y).equals("WhiteKing")){
		// JOptionPane.showMessageDialog(null, "White wins!");
		// return true;
		// }
		else {
			return false;
		}

	}*/ 
	
////METHOD TO SEE IF KING IS CAPTURED AND TO WIN THE GAME - WORKING
	private Boolean isKingCaputered(int x, int y){
	if ((piecePresent(x, y)) && getPieceName(x, y).contains("King")) { // similar to isKingNearby(), but this gets
																			// the x,y of where the piece is landing.

			if (getPieceName(x, y).contains("BlackKing")) { // if it's a black king, white wins
				JOptionPane.showMessageDialog(null, "White wins!");
				System.exit(0);
			} else if (getPieceName(x, y).contains("WhiteKing")) { // if it's a white king, white wins
				JOptionPane.showMessageDialog(null, "Black wins!");
				System.exit(0);
			}
			return true;
		}
		// else if((piecePresent(x, y)) && getPieceName(x, y).equals("WhiteKing")){
		// JOptionPane.showMessageDialog(null, "White wins!");
		// return true;
		// }
		else {
			return false;
		}

	}

////ATTEMPT AT isKingCaptured()
/* 	private void gameEnds(String winningColour){
	gameOver = true;
	if(winningColour.contains("White"))
		{
            JOptionPane.showMessageDialog(null, "White wins!");
            System.exit(0);
        } else
        {
            JOptionPane.showMessageDialog(null, "Black wins!");
            System.exit(0);
        }
	} */
	

	// // was trying to switch players, but learnt that it was not required for Project 1
/* 	private void switchPlayer(){
		String tmp = chessPiece.getIcon().toString();
		String pieceName = tmp.substring(0, (tmp.length() - 4));
		if(whiteMoves = true){
			if(pieceName.contains("Black")){
				JOptionPane.showMessageDialog(null, "It's Black's turn!");
			}
		}
		else{ //else if (!(whiteMoves = true)){}
			if(pieceName.contains("White")){
				JOptionPane.showMessageDialog(null, "It's White's turn!");
			}
		}
	} */

	/*
	 * This method is called when we press the Mouse. So we need to find out what
	 * piece we have selected. We may also not have selected a piece!
	 */
	public void mousePressed(MouseEvent e) { //the gets the chess piece when the mouse is pressed and drags it to new location
		chessPiece = null;
		Component c = chessBoard.findComponentAt(e.getX(), e.getY());
		if (c instanceof JPanel)
			return;

		Point parentLocation = c.getParent().getLocation();
		xAdjustment = parentLocation.x - e.getX();
		yAdjustment = parentLocation.y - e.getY();
		chessPiece = (JLabel) c;
		initialX = e.getX();
		initialY = e.getY();
		startX = (e.getX() / 75);
		startY = (e.getY() / 75);
		chessPiece.setLocation(e.getX() + xAdjustment, e.getY() + yAdjustment);
		chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight());
		layeredPane.add(chessPiece, JLayeredPane.DRAG_LAYER);
	}

	public void mouseDragged(MouseEvent me) { //this checks to see if when the mouse is dragged, if a piece is being dragged with it.
		if (chessPiece == null)
			return;
		chessPiece.setLocation(me.getX() + xAdjustment, me.getY() + yAdjustment);
	}

	/*
	 * This method is used when the Mouse is released...we need to make sure the
	 * move was valid before putting the piece back on the board.
	 */
	public void mouseReleased(MouseEvent e) { // this removes the piece under the dragged piece if it's a valid move
		if (chessPiece == null)
			return;

		chessPiece.setVisible(false);
		success = false;
		progression = false;
		Component c = chessBoard.findComponentAt(e.getX(), e.getY());
		String tmp = chessPiece.getIcon().toString();
		String pieceName = tmp.substring(0, (tmp.length() - 4));
		Boolean validMove = false;

		int landingX = 0;
		int landingY = 0;
		double getX = e.getX();
		double getY = e.getY();

		if ((getX < 0) && (getY >= 0)) { // these if/else ifs round down the e.getX / e.getY to give say y = -1 (rounded
											// down from e.g. -0.25), instead of rounding up to 0 (from -0.25)
			double landingX_d = Math.floor(getX / 75); // landingX_d is short for landingX_double
			landingX = (int) (landingX_d);
			landingY = (e.getY() / 75);
			// System.out.println(Math.floor(getX/75));
		} else if ((getX >= 0) && (getY < 0)) {
			double landingY_d = Math.floor(getY / 75); // landingY_d is short for landingY_double
			landingX = (e.getX() / 75);
			landingY = (int) (landingY_d);
			// System.out.println(Math.floor(getY/75));
		} else if ((getX < 0) && (getY < 0)) {
			double landingX_d = Math.floor(getX / 75);
			double landingY_d = Math.floor(getY / 75);

			landingX = (int) (landingX_d);
			landingY = (int) (landingY_d);
			// System.out.println(Math.floor(getX/75) + ", " + Math.floor(getY/75));
		} else if ((getX >= 0) && (getY >= 0)) { // I know a simple "else()" statement would work here. Though, I wanted
													// to ensure the code was doing exactly as I wanted.
			landingX = (e.getX() / 75);
			landingY = (e.getY() / 75);
		}
		int xMovement = Math.abs((e.getX() / 75) - startX);
		int yMovement = Math.abs((e.getY() / 75) - startY);
		System.out.println("---------------------------------------------");
		System.out.println("Current piece: " + pieceName);
		System.out.println("Start: (" + startX + "," + startY + ")");
		System.out.println("xMovement: " + xMovement);
		System.out.println("yMovement: " + yMovement);
		System.out.println("Landing: (" + landingX + "," + landingY + ")");
		System.out.println("---------------------------------------------");

		/*
			The only piece that has been enabled to move is a White Pawn...but we should really have this is a separate
			method somewhere...how would this work.
			
			So a Pawn is able to move two squares forward one its first go but only one square after that. 
			The Pawn is the only piece that cannot move backwards in chess...so be careful when committing 
			a pawn forward. A Pawn is able to take any of the opponent’s pieces but they have to be one 
			square forward and one square over, i.e. in a diagonal direction from the Pawns original position. 
			If a Pawn makes it to the top of the other side, the Pawn can turn into any other piece, for 
			demonstration purposes the Pawn here turns into a Queen.
		*/

////////// ** TAKING TURNS **
////////// ** not required for Project 1, also it's not working

		/* int inPlays = 5000;
		for (int plays = 0; plays < inPlay; plays++, inPlays--) {
			Boolean blacksTurn;
			Boolean whitesTurn;
			if (plays % 2 == 0) { // if even number, white's turn
				if (pieceName.contains("Black")) {
					blacksTurn = false;
					JOptionPane.showMessageDialog(null, infoMessage, "White's turn!");
				} else { // else if(pieceName.contains("White")){
					whitesTurn = true;
				}
			} else if(plays%2 != 0){ // if odd, black's turn
				if (pieceName.contains("White")) {
					whitesTurn = false;
					JOptionPane.showMessageDialog(null, infoMessage, "Black's turn!");
				} else { // else if(pieceName.contains("Black")){
					blacksTurn = true;
				}
			} else if (checkmake){
				inplays = 0;
			}
		} */

		//while(!(gameOver)){


////////// ** KING **
		if (pieceName.contains("King")) {
			Boolean k_rook_inTheWay = false;
			Boolean k_bishop_inTheWay = false;
			int distanceX = Math.abs(startX - landingX); // posiiton of X
			int distanceY = Math.abs(startY - landingY); // position of Y
			if ((landingX < 0) || (landingX > 7) || (landingY < 0) || landingY > 7) { // to ensure pieces are kept on
																						// the board.
				validMove = false;
			} else {
				if (!(isKingNearby(e.getX(), e.getY()))) { // if the king is not near the other king.
					validMove = true;
					if (((yMovement == 1) && (xMovement == 1)) || ((yMovement == 0) && (xMovement == 1))
							|| ((yMovement == 1) && (xMovement == 0))) { // king moves one place on x/y axis. (like
																			// bishop)
						if ((startX - landingX < 0) && (startY - landingY < 0)) { // checks where the King lands in a
																					// particular direction and if
																					// another piece is present
							for (int i = 0; i < distanceX; i++) {
								if (piecePresent((initialX + (75 * i)), (initialY + (75 * i)))) {
									k_bishop_inTheWay = true;
								}
							}
						}

						else if ((startX - landingX < 0) && (startY - landingY > 0)) { // checks where the King lands in
																						// a particular direction and if
																						// another piece is present
							for (int i = 0; i < distanceX; i++) {
								if (piecePresent((initialX + (75 * i)), (initialY - (75 * i)))) {
									k_bishop_inTheWay = true;
								}
							}
						}

						else if ((startX - landingX > 0) && (startY - landingY > 0)) { // checks where the King lands in
																						// a particular direction and if
																						// another piece is present
							for (int i = 0; i < distanceX; i++) {
								if (piecePresent((initialX - (75 * i)), (initialY - (75 * i)))) {
									k_bishop_inTheWay = true;
								}
							}
						}

						else if ((startX - landingX > 0) && (startY - landingY < 0)) { // checks where the King lands in
																						// a particular direction and if
																						// another piece is present
							for (int i = 0; i < distanceX; i++) {
								if (piecePresent((initialX - (75 * i)), (initialY + (75 * i)))) {
									k_bishop_inTheWay = true;
								}
							}
						}

						if (k_bishop_inTheWay) { // if a piece in in the was in an diagonal axis
							validMove = false;
						} else if (isKingNearby(e.getX(), e.getY())) { // if king is two spaces away, not king not
																		// allowed to move.
							validMove = false;
						} else {
							if (piecePresent(e.getX(), e.getY())) { // checks whether oponent present is black or white,
																	// or if it's the King
								if (pieceName.contains("White")) {
									if (checkWhiteOponent(e.getX(), e.getY())) {
										//isKingCaputered(startX, startY, e.getX(), e.getY());
										isKingCaputered(e.getX(), e.getY());
										validMove = true;
									} else {
										validMove = false;
									}
								} else { // else if(pieceName.contains("Black")){ //checks whether oponent present is
											// black or white, or if it's the King
									if (checkBlackOponent(e.getX(), e.getY())) {
										//isKingCaputered(startX, startY, e.getX(), e.getY());
										isKingCaputered(e.getX(), e.getY());
										validMove = true;
									} else {
										validMove = false;
									}
								}
							} else {
								validMove = true;
							}
						}
					} else if (((Math.abs(startX - landingX) != 0) && (Math.abs(startY - landingY) == 0))
							|| (((Math.abs(startX - landingX) == 0) && (Math.abs(landingY - startY) != 0)))) {
						if (Math.abs(startX - landingX) != 0) { // king moves one place on x/y axis. (like rook)
							xMovement = Math.abs(startX - landingX);
							if (startX - landingX > 0) {
								for (int i = 0; i < xMovement; i++) { // checks where the King lands in a particular
																		// direction and if another piece is present
									if (piecePresent((initialX - (i * 75)), e.getY())) {
										k_rook_inTheWay = true;
										break;
									} else {
										k_rook_inTheWay = false;
									}
								}
							} else {
								for (int i = 0; i < xMovement; i++) { // checks where the King lands in a particular
																		// direction and if another piece is present
									if (piecePresent((initialX - (i * 75)), e.getY())) {
										k_rook_inTheWay = true;
										break;
									} else {
										k_rook_inTheWay = false;
									}
								}
							}
						} else {
							yMovement = Math.abs(startY - landingY);
							if (startY - landingY > 0) {
								for (int i = 0; i < yMovement; i++) { // checks where the King lands in a particular
																		// direction and if another piece is present
									if (piecePresent(e.getX(), (initialY - (i * 75)))) {
										k_rook_inTheWay = true;
										break;
									} else {
										k_rook_inTheWay = false;
									}
								}
							} else {
								for (int i = 0; i < yMovement; i++) { // checks where the King lands in a particular
																		// direction and if another piece is present
									if (piecePresent(e.getX(), (initialY + (i * 75)))) {
										k_rook_inTheWay = true;
										break;
									} else {
										k_rook_inTheWay = false;
									}
								}
							}
						}
						if (k_rook_inTheWay) { // if a piece is in the was in the Plus axis, e.g. x=1, y+0.
							validMove = false;
						} else {
							if (piecePresent(e.getX(), e.getY())) { // checks whether oponent present is black or white,
																	// or if it's the King
								if (pieceName.contains("White")) {
									if (checkWhiteOponent(e.getX(), e.getY())) {
										//isKingCaputered(startX, startY, e.getX(), e.getY());
										isKingCaputered(e.getX(), e.getY());
										validMove = true;
									} else {
										validMove = false;
									}
								} else { // else if(pieceName.contains("Black")){ //checks whether oponent present is
											// black or white, or if it's the King
									if (checkBlackOponent(e.getX(), e.getY())) {
										//isKingCaputered(startX, startY, e.getX(), e.getY());
										isKingCaputered(e.getX(), e.getY());
										validMove = true;
									} else {
										validMove = false;
									}
								}
							} else {
								validMove = true;
							}
						}
					} else {
						validMove = false;
					}
				} else {
					validMove = false;
				}
			}

		}

////////// ** ROOK **
		if (pieceName.contains("Rook")) {
			Boolean rook_inTheWay = false;
			if (((landingX < 0) || (landingX > 7)) || ((landingY < 0) || (landingY > 7))) { // to ensure pieces are kept
																							// on the board.
				validMove = false;
			} else {
				if (((Math.abs(startX - landingX) != 0) && (Math.abs(startY - landingY) == 0))
						|| (((Math.abs(startX - landingX) == 0) && (Math.abs(landingY - startY) != 0)))) {
					if (Math.abs(startX - landingX) != 0) { // The rook can only move in a certain way on the Plus axis
						xMovement = Math.abs(startX - landingX);
						if (startX - landingX > 0) {
							for (int i = 0; i < xMovement; i++) { // checks where the Rook lands in a particular
																	// direction and if another piece is present
								if (piecePresent((initialX - (i * 75)), e.getY())) {
									rook_inTheWay = true;
									break;
								} else {
									rook_inTheWay = false;
								}
							}
						} else {
							for (int i = 0; i < xMovement; i++) { // checks where the Rook lands in a particular
																	// direction and if another piece is present
								if (piecePresent((initialX - (i * 75)), e.getY())) {
									rook_inTheWay = true;
									break;
								} else {
									rook_inTheWay = false;
								}
							}
						}
					} else {
						yMovement = Math.abs(startY - landingY);
						if (startY - landingY > 0) {
							for (int i = 0; i < yMovement; i++) { // checks where the Rook lands in a particular
																	// direction and if another piece is present
								if (piecePresent(e.getX(), (initialY - (i * 75)))) {
									rook_inTheWay = true;
									break;
								} else {
									rook_inTheWay = false;
								}
							}
						} else {
							for (int i = 0; i < yMovement; i++) { // checks where the Rook lands in a particular
																	// direction and if another piece is present
								if (piecePresent(e.getX(), (initialY + (i * 75)))) {
									rook_inTheWay = true;
									break;
								} else {
									rook_inTheWay = false;
								}
							}
						}
					}
					if (rook_inTheWay) {
						validMove = false;
					} else {
						if (piecePresent(e.getX(), e.getY())) {
							if (pieceName.contains("White")) {
								if (checkWhiteOponent(e.getX(), e.getY())) { // checks whether oponent present is black
																				// or white, or if it's the King
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							} else { // else if(pieceName.contains("Black")){ //checks whether oponent present is
										// black or white, or if it's the King
								if (checkBlackOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							}
						} else {
							validMove = true;
						}
					}
				} else {
					validMove = false;
				}
			}
		}

////////// ** BISHOP **
		else if (pieceName.contains("Bishop")) { // from workbook
			Boolean bishop_inTheWay = false;
			int distanceX = Math.abs(startX - landingX); // changed 'distance' to 'distanceX'
			int distanceY = Math.abs(startY - landingY); // added as 'if function' below was not working

			if ((!(landingX >= 0)) || (!(landingX < 8)) || (!(landingY >= 0)) || (!(landingY < 8))) { // **** ERROR WITH JAVA CODEC -
																						// "landingX < 0" is not working
																						// at all. It should, but
																						// doesn't. Possible bug with
																						// the Java packages.
				validMove = false;
			} else {
				validMove = true;
				// if (Math.abs(startX - landingY) == Math.abs(startY - landingY)) { // not
				// working, makes bishop not move
				if (distanceX == distanceY) {
					if ((startX - landingX < 0) && (startY - landingY < 0)) {
						for (int i = 0; i < distanceX; i++) {// checks where the Rook lands in a particular direction
																// and if another piece is present
							if (piecePresent((initialX + (75 * i)), (initialY + (75 * i)))) {
								bishop_inTheWay = true;
							}
						}
					}

					else if ((startX - landingX < 0) && (startY - landingY > 0)) {
						for (int i = 0; i < distanceX; i++) { // checks where the Rook lands in a particular direction
																// and if another piece is present
							if (piecePresent((initialX + (75 * i)), (initialY - (75 * i)))) {
								bishop_inTheWay = true;
							}
						}
					}

					else if ((startX - landingX > 0) && (startY - landingY > 0)) {
						for (int i = 0; i < distanceX; i++) { // checks where the Rook lands in a particular direction
																// and if another piece is present
							if (piecePresent((initialX - (75 * i)), (initialY - (75 * i)))) {
								bishop_inTheWay = true;
							}
						}
					}

					else if ((startX - landingX > 0) && (startY - landingY < 0)) {
						for (int i = 0; i < distanceX; i++) { // checks where the Rook lands in a particular direction
																// and if another piece is present
							if (piecePresent((initialX - (75 * i)), (initialY + (75 * i)))) {
								bishop_inTheWay = true;
							}
						}
					}

					if (bishop_inTheWay) { // if bishop moves and piece is obstructing it, the valid move is false
						validMove = false;
					} else {
						if (piecePresent(e.getX(), e.getY())) {
							if (pieceName.contains("White")) { // checks whether oponent present is black or white, or
																// if it's the King
								if (checkWhiteOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							} else { // else if(pieceName.contains("Black")){ //checks whether oponent present is
										// black or white, or if it's the King
								if (checkBlackOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							}
						} else {
							validMove = true;
						}
					}
				} else {
					validMove = false;
				}
			}
		}

////////// ** KNIGHT **
		else if (pieceName.contains("Knight")) { // From Keith's video
			if (((landingX < 0) || (landingX > 7)) || ((landingY < 0) || (landingY > 7))) { // to ensure pieces are kept
																							// on the board.
				validMove = false;
			} else {
				if (((xMovement == 1) && (yMovement == 2)) || ((xMovement == 2) && (yMovement == 1))) { // if Knight
																										// moves in an
																										// "L" shape
					if (!piecePresent(e.getX(), e.getY())) { // if not piece present, it's a valid move
						validMove = true;

					} else {
						if (pieceName.contains("White")) {// checks whether oponent present is black or white, or if
															// it's the King
							if (checkWhiteOponent(e.getX(), e.getY())) {
								//isKingCaputered(startX, startY, e.getX(), e.getY());
								isKingCaputered(e.getX(), e.getY());
								validMove = true;
							}
						} else { // else if(pieceName.contains("Black")){//checks whether oponent present is
									// black or white, or if it's the King
							if (checkBlackOponent(e.getX(), e.getY())) {
								//isKingCaputered(startX, startY, e.getX(), e.getY());
								isKingCaputered(e.getX(), e.getY());
								validMove = true;
							}

						}
					}
				}
			}
		}

////////// ** QUEEN **
		else if (pieceName.contains("Queen")) {
			Boolean q_rook_inTheWay = false;
			Boolean q_bishop_inTheWay = false;
			int distanceX = Math.abs(startX - landingX);
			int distanceY = Math.abs(startY - landingY);
			if ((landingX < 0) || (landingX > 7) || (landingY < 0) || landingY > 7) {// to ensure pieces are kept on the
																						// board.
				validMove = false;
			} else {
				validMove = true;
				if (distanceX == distanceY) { // king move one place on x/y axis. (like bishop)
					if ((startX - landingX < 0) && (startY - landingY < 0)) { // checks where the Queen lands in a
																				// particular direction and if another
																				// piece is present
						for (int i = 0; i < distanceX; i++) {
							if (piecePresent((initialX + (75 * i)), (initialY + (75 * i)))) {
								q_bishop_inTheWay = true;
							}
						}
					}

					else if ((startX - landingX < 0) && (startY - landingY > 0)) { // checks where the Queen lands in a
																					// particular direction and if
																					// another piece is present
						for (int i = 0; i < distanceX; i++) {
							if (piecePresent((initialX + (75 * i)), (initialY - (75 * i)))) {
								q_bishop_inTheWay = true;
							}
						}
					}

					else if ((startX - landingX > 0) && (startY - landingY > 0)) { // checks where the Queen lands in a
																					// particular direction and if
																					// another piece is present
						for (int i = 0; i < distanceX; i++) {
							if (piecePresent((initialX - (75 * i)), (initialY - (75 * i)))) {
								q_bishop_inTheWay = true;
							}
						}
					}

					else if ((startX - landingX > 0) && (startY - landingY < 0)) { // checks where the Queen lands in a
																					// particular direction and if
																					// another piece is present
						for (int i = 0; i < distanceX; i++) {
							if (piecePresent((initialX - (75 * i)), (initialY + (75 * i)))) {
								q_bishop_inTheWay = true;
							}
						}
					}

					if (q_bishop_inTheWay) { // if a piece in in the was in an diagonal axis
						validMove = false;
					} else {
						if (piecePresent(e.getX(), e.getY())) { // checks whether oponent present is black or white, or
																// if it's the King
							if (pieceName.contains("White")) {
								if (checkWhiteOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							} else if (pieceName.contains("Black")) { // checks whether oponent present is black or
																		// white, or if it's the King
								if (checkBlackOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							}
						} else {
							validMove = true;
						}
					}
				} else if (((Math.abs(startX - landingX) != 0) && (Math.abs(startY - landingY) == 0))
						|| (((Math.abs(startX - landingX) == 0) && (Math.abs(landingY - startY) != 0)))) {
					if (Math.abs(startX - landingX) != 0) { // queen moves on x/y axis. (like rook)
						xMovement = Math.abs(startX - landingX);
						if (startX - landingX > 0) { // checks where the Queen lands in a particular direction and if
														// another piece is present
							for (int i = 0; i < xMovement; i++) {
								if (piecePresent((initialX - (i * 75)), e.getY())) {
									q_rook_inTheWay = true;
									break;
								} else {
									q_rook_inTheWay = false;
								}
							}
						} else {
							for (int i = 0; i < xMovement; i++) { // checks where the Queen lands in a particular
																	// direction and if another piece is present
								if (piecePresent((initialX - (i * 75)), e.getY())) {
									q_rook_inTheWay = true;
									break;
								} else {
									q_rook_inTheWay = false;
								}
							}
						}
					} else {
						yMovement = Math.abs(startY - landingY);
						if (startY - landingY > 0) { // checks where the Queen lands in a particular direction and if
														// another piece is present
							for (int i = 0; i < yMovement; i++) {
								if (piecePresent(e.getX(), (initialY - (i * 75)))) {
									q_rook_inTheWay = true;
									break;
								} else {
									q_rook_inTheWay = false;
								}
							}
						} else {
							for (int i = 0; i < yMovement; i++) { // checks where the Queen lands in a particular
																	// direction and if another piece is present
								if (piecePresent(e.getX(), (initialY + (i * 75)))) {
									q_rook_inTheWay = true;
									break;
								} else {
									q_rook_inTheWay = false;
								}
							}
						}
					}
					if (q_rook_inTheWay) { // if a piece is in the was in the Plus axis, e.g. x=1, y+0.
						validMove = false;
					} else {
						if (piecePresent(e.getX(), e.getY())) {// checks whether oponent present is black or white, or
																// if it's the King
							if (pieceName.contains("White")) {
								if (checkWhiteOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
								} else {
									validMove = false;
								}
							} else if (pieceName.contains("Black")) { // checks whether oponent present is black or
																		// white, or if it's the King
								if (checkBlackOponent(e.getX(), e.getY())) {
									//isKingCaputered(startX, startY, e.getX(), e.getY());
									isKingCaputered(e.getX(), e.getY());
									validMove = true;
								} else {
									validMove = false;
								}
							}
						} else {
							validMove = true;
						}
					}
				} else {
					validMove = false;
				}
			}

		}

////////// ** BLACK PAWN FROM KEITH MAYCOCK'S VIDEO **
		else if (pieceName.equals("BlackPawn")) {
			if ((landingX < 0) || (landingX > 7) || (landingY < 0) || landingY > 7) {// to ensure pieces are kept on the
																						// board.
				validMove = false;
			} else {
				if (startY == 6) { // if black pawn is at its starting point on the y axis
					if (((yMovement == 1) && (startY > landingY) && (xMovement == 0))
							|| ((yMovement == 2) && (startY > landingY) && (xMovement == 0))) { // startY is greater
																								// than landingY togo up
																								// the board, xMovement
																								// == 0 to stop Pawn
																								// from going side to
																								// side (on X axis).
						if (yMovement == 2) { // if black pawn is NOT at its starting position on the y axis.
							if ((!piecePresent(e.getX(), e.getY())) && (!piecePresent(e.getX(), (e.getY() + 75)))) { // checks
																														// if
																														// another
																														// piece
																														// is
																														// present
								validMove = true;
							}
						} else {
							if (!piecePresent(e.getX(), e.getY())) {
								validMove = true;

							}
						}

					} else if ((yMovement == 1) && (startY > landingY) && (xMovement == 1)) {// black pawn is moving up
																								// the board
						if (piecePresent(e.getX(), e.getY())) {// checks if another piece is present
							if (checkBlackOponent(e.getX(), e.getY())) {// checks whether oponent present is black or
																		// white, or if it's the King
								//isKingCaputered(startX, startY, e.getX(), e.getY());
								isKingCaputered(e.getX(), e.getY());
								validMove = true;
							}
						}
					}
				} else {
					if ((yMovement == 1) && (startY > landingY) && (xMovement == 0)) {
						if (!piecePresent(e.getX(), e.getY())) {
							validMove = true;
							if (startY == 1) {
								progression = true;
							}
						}
					} else if ((yMovement == 1) && (startY > landingY) && (xMovement == 1)) {
						if (piecePresent(e.getX(), e.getY())) {// checks if another piece is present
							if (checkBlackOponent(e.getX(), e.getY())) {// checks whether oponent present is black or
																		// white, or if it's the King
								//isKingCaputered(startX, startY, e.getX(), e.getY());
								isKingCaputered(e.getX(), e.getY());
								validMove = true;
								if (startY == 1) {
									progression = true;
								}

							}
						}
					}
				}
			}
		}

////////////// BLACK PAWN FROM WORKBOOK/MANUAL
			// **** code from workbook for BLACK PAWN, does not work at all. ****
			/* else if(pieceName.equals("Black Pawn")){ //code from workbook, does not work at all.
				if((startY == 6) && (startX == landingX) && (((startY - landingY) == 1) || (startY - landingY) == 2)){ // issue
					// if (black pawn is at y=6 && startX and landingX are same && y moves 1 place) || (y moves 2 places)

					if(!piecePresent(e.getX(), e.getY())){ //if no piece present, it's a valid move
						validMove = true;
					}
					else{
						validMove = false;
					}
				}
				else if((Math.abs(startX - landingX) == 1) && (((startY - landingY) == 1))){
					//if(x moves 1 place && y moves 1 place)

					if(piecePresent(e.getX(), e.getY())){ // if piece present
						if(checkBlackOponent(e.getX(), e.getY())){ //check if a black oponent
							validMove = true;
							if(landingY == 0){ // if black pawn reaches top of board
								progression = true;
							}
						}
						else{ //if NOT a black oponent, i.e. black piece
							validMove = false;
						}
					}
					else{
						validMove = false;
					}

				}
				else if((startY != 6) && ((startX == landingX) && (((startY - landingY) == 1)))){
					//if( y != 6, and moving y by 1 place)

					if(!piecePresent(e.getX(), e.getY())){ // if piece present
						validMove = true;
						if(landingY == 0){
							progression = true;
						}
					}
					else{
						validMove = false;
					}
				}
				else{
					validMove = false;
				}
			} */

////////// ** WHITE PAWN **
		else if (pieceName.equals("WhitePawn")) {
			if ((landingX < 0) || (landingX > 7) || (landingY < 0) || landingY > 7) {// to ensure pieces are kept on the
																						// board.
				validMove = false;
			} else {
				if (startY == 1) { // chacks if white pawn is at its starting point
					if ((startX == (e.getX() / 75))
							&& ((((e.getY() / 75) - startY) == 1) || ((e.getY() / 75) - startY) == 2)) { // checking
																											// movements
																											// of white
																											// pawn
						if ((((e.getY() / 75) - startY) == 2)) {
							if ((!piecePresent(e.getX(), (e.getY()))) && (!piecePresent(e.getX(), (e.getY() + 75)))) { // if
																														// piece
																														// not
																														// present,
																														// it's
																														// a
																														// valid
																														// move
								validMove = true;
							} else {
								validMove = false;
							}
						} else {
							if ((!piecePresent(e.getX(), (e.getY())))) { // if piece not present, it's a valid move
								validMove = true;
							} else {
								validMove = false;
							}
						}
					} else {
						validMove = false;
					}
				} else { // if white pawn is NOT at its starting point
					int newY = e.getY() / 75;
					int newX = e.getX() / 75;
					if ((startX - 1 >= 0) || (startX + 1 <= 7)) {
						if ((piecePresent(e.getX(), (e.getY()))) && ((((newX == (startX + 1) && (startX + 1 <= 7)
								&& newY == (startY + 1) && (startY <= 7)))
								|| ((newX == (startX - 1)) && (startX - 1 >= 0) && newY == (startY + 1)
										&& (startY <= 7))))) {// ensures piece is moving down the board and stays on the
																// board.
							// if(piecepresent &&
							// ((newX going right by 1 but cannot go off board) && (newY is going down by 1,
							// but cannot go off board )) ||
							// ((newX going left by 1, but cannot go off board) && (newY is going down by 1,
							// but cannot go off board) )
							// Note: newY cannot go up 1, so newY .. -1 cannot exist

							if (checkWhiteOponent(e.getX(), e.getY())) {// checks whether oponent present is black or
																		// white, or if it's the King
								//isKingCaputered(startX, startY, e.getX(), e.getY());
								isKingCaputered(e.getX(), e.getY());
								validMove = true;
								if (startY == 6) {
									success = true;
								}
							} else {
								validMove = false;
							}
						} else {
							if (!piecePresent(e.getX(), (e.getY()))) {
								if ((startX == (e.getX() / 75)) && ((e.getY() / 75) - startY) == 1) { // if white pawn
																										// is one from
																										// the bottom
									if (startY == 6) {
										success = true;
									}
									validMove = true;
								} else {
									validMove = false;
								}
							} else {
								validMove = false;
							}
						}
					} else {
						validMove = false;
					}
				}
			}
		}

////////////// IF NOT A VALID MOVE / PROGRESSION / SUCCESS

		/* if (!validMove) {
			int location= 0;
			if (startX == 0 && startY == 0) {
				location = 0;
			}
			else if (startX == 1 && startY == 0){
				location = 1;
			}
			else if (startX == 2 && startY == 0){
				location = 2;
			}
			else if (startX == 3 && startY == 0){
				location = 3;
			}
			else if (startX == 4 && startY == 0){
				location = 4;
			}
			else if (startX == 5 && startY == 0){
				location = 5;
			}
			else if (startX == 6 && startY == 0){
				location = 6;
			}
			else {
				location = (startY * 8) + startX;
			}
			String pieceLocation = pieceName + ".png";
			pieces = new JLabel(new ImageIcon(pieceLocation));
			panels = (JPanel) chessBoard.getComponent(location);
			panels.add(pieces);
		} else... */
		if (!validMove) {
			int location;
			if (startY == 0) {
				location = startX;
			} else {
				location = (startY * 8) + startX;
			}
			String pieceLocation = pieceName + ".png";
			pieces = new JLabel(new ImageIcon(pieceLocation));
			panels = (JPanel) chessBoard.getComponent(location);
			panels.add(pieces);
		} else {
			if (progression) { // used for the Black Pawn when it reaches the top to turn it into a BlackQueen
				int location = 0 + (e.getX() / 75);
				if (c instanceof JLabel) {
					Container parent = c.getParent();
					parent.remove(0);
					pieces = new JLabel(new ImageIcon("BlackQueen.png"));
					pieceName = "BlackQueen.png";
					parent = (JPanel) chessBoard.getComponent(location);
					parent.add(pieces);
				}
			} else if (success) { // used for the White Pawn when it reaches the top to turn it into a WhiteQueen
				int location = 56 + (e.getX() / 75);
				if (c instanceof JLabel) {
					Container parent = c.getParent();
					parent.remove(0);
					pieces = new JLabel(new ImageIcon("WhiteQueen.png"));
					pieceName = "WhiteQueen.png";
					parent = (JPanel) chessBoard.getComponent(location);
					parent.add(pieces);
				} else {
					Container parent = (Container) c;
					pieces = new JLabel(new ImageIcon("WhiteQueen.png"));
					pieceName = "WhiteQueen.png";
					parent = (JPanel) chessBoard.getComponent(location);
					parent.add(pieces);
				}
			} else {
				if (c instanceof JLabel) {
					Container parent = c.getParent();
					parent.remove(0);
					parent.add(chessPiece);
				} else {
					Container parent = (Container) c;
					parent.add(chessPiece);
				}
				chessPiece.setVisible(true);
			}
		}
	}
	// }

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseMoved(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	/*
	 * Main method that gets the ball moving.
	 */
	public static void main(String[] args) {
		JFrame frame = new ChessProject();
		frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		frame.pack();
		frame.setResizable(true);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
